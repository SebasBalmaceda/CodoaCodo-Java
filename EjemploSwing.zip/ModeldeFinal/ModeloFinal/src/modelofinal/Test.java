/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelofinal;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Test {
      static final int  HoraNormal = 120;
      static final int  HoraExtra = 150;
      static final int  AntiguedadNormal =800;
      static final int  AntiguedadAdicional =300;
      static final int  RetencionNormal =18000;
      static final int  P1 =20;
      static final int  P2=24;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                                                   //main que va a calcular el sueldo a precibir el empleado
                       int acu1=0;  //variables para la hora
                       int acu2=0;
                       int acu3=0;
                       int acu4=0;
                       int auxAnio=0; //variables para los años
                       int auxAnio2=0;
                       int auxAnio3=0;
                       int auxAnio4=0;
                       int sueldoBruto=0; //variables para el sueldo
                       int sueldoNeto=0;
                       int porcentaje=0;        
                       Scanner s = new Scanner(System.in);
                       System.out.println("ingrese la cantidad de horas trabajadas por mes ");
                       int hora= s.nextInt();
                       System.out.println("ingrese la antiguedad del empleado en años ");
                       int antiguedad= s.nextInt();
                       System.out.println("las horas ingresadas son : "+hora+"hs"+"y los años ingresados son"+antiguedad+"años"); 
                       
                       //Calculo de Horas a Pagar
                       acu1=hora-120;
                           if(acu1==0){
                            acu2=hora*HoraNormal;
                            
                            }
                            acu2=acu1*HoraExtra;
                            acu3=(hora-acu1)*HoraNormal;
                            acu4=acu3+acu2;
                            System.out.println("hora trabajadas"+hora);
                            System.out.println("hora normal a pagar "+acu3);
                            System.out.println("hora extra a pagar "+acu2);
                            System.out.println("total de horas a pagar "+acu4);
                     
                         //Calculo de años a Pagar
                        
                            auxAnio=antiguedad%5;
                            if(auxAnio==0){
                            auxAnio2=antiguedad*AntiguedadNormal;
                            }
                            auxAnio3=auxAnio*AntiguedadAdicional;
                            auxAnio2=(antiguedad-auxAnio)*AntiguedadNormal;
                            auxAnio4=auxAnio3+auxAnio2;
                          
                            System.out.println("Años trabajados"+antiguedad);
                            System.out.println("adicional por  años "+auxAnio2);
                            System.out.println("remanente a pagar "+auxAnio3);
                           
                          //Retencion al Sueldo
                           sueldoBruto=acu4+auxAnio4;
                           System.out.println("Sueldo Bruto Hasta el momento: "+sueldoBruto);
                           
                                if(sueldoBruto<=RetencionNormal){
                                porcentaje=((sueldoBruto*P1)/100);
                                }else{
                                porcentaje=((sueldoBruto*P2)/100);    
                                }
                                sueldoNeto=sueldoBruto-porcentaje;
                                System.out.println("Sueldo Neto a percibir: "+sueldoNeto);
            
                }



}