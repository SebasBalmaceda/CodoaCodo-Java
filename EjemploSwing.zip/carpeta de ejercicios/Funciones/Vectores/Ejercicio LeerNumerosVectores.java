/* Este codigo ha sido generado por el modulo psexport 20160506-w32 de PSeInt.
Es posible que el codigo generado no sea completamente correcto. Si encuentra
errores por favor reportelos en el foro (http://pseint.sourceforge.net). */

// En java, el nombre de un archivo fuente debe coincidir con el nombre de la clase que contiene,
// por lo que este archivo deber�a llamarse "LEERNUMEROSVECTOR.java."

import java.io.*;

public class leernumerosvector {

	public static void main(String args[]) throws IOException {
		BufferedReader bufEntrada = new BufferedReader(new InputStreamReader(System.in));
		int i;
		int n;
		String numeros[];
		// sobredimensionamos el vector para el usuario
		numeros = new String[100];
		n = 0;
		System.out.println("Ingrese la cantidad de datos a leer");
		n = Integer.parseInt(bufEntrada.readLine());
		for (i=1;i<=n;i++) {
			System.out.println("ingrese el dato para la posicion: "+i);
			numeros[i-1] = bufEntrada.readLine();
		}
		for (i=1;i<=n;i++) {
			System.out.println("El elemento en la posicion :"+i+" es: "+numeros[i-1]);
		}
	}


}

