/* Este codigo ha sido generado por el modulo psexport 20160506-w32 de PSeInt.
Es posible que el codigo generado no sea completamente correcto. Si encuentra
errores por favor reportelos en el foro (http://pseint.sourceforge.net). */

// En java, el nombre de un archivo fuente debe coincidir con el nombre de la clase que contiene,
// por lo que este archivo deber�a llamarse "MATRICESYVECTORES.java."

import java.io.*;

public class matricesyvectores {

	public static void main(String args[]) throws IOException {
		BufferedReader bufEntrada = new BufferedReader(new InputStreamReader(System.in));
		int i;
		int j;
		int k;
		int l;
		int matriz[][];
		int veccol[];
		int vecfila[];
		matriz = new int[2][2];
		vecfila = new int[2];
		veccol = new int[2];
		for (i=0;i<=1;i++) {
			for (j=0;j<=1;j++) {
				System.out.println("Ingrese Valor: ");
				matriz[i][j] = Integer.parseInt(bufEntrada.readLine());
			}
		}
		// conviene usar aca la suma de los vectores porque no cuando los lee
		// es mas complicado.
		for (i=0;i<=1;i++) {
			for (j=0;j<=1;j++) {
				vecfila[i] = vecfila[i]+matriz[i][j];
				veccol[j] = veccol[j]+matriz[i][j];
				System.out.println("El valor de fila "+i+" y columna "+j+" es : "+matriz[i][j]);
			}
		}
		for (k=0;k<=1;k++) {
			System.out.println(" la suma de las filas dan :"+vecfila[k]);
		}
		for (l=0;l<=1;l++) {
			System.out.println(" la suma de las columnas dan :"+veccol[l]);
		}
	}


}

