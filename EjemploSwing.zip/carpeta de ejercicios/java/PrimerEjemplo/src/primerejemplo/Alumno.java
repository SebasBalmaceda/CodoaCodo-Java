/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerejemplo;

/**
 *
 * @author Alumno
 */
public class Alumno {   /* clase alumno con un atributo nombre que es privado*/
    private String nombre; 
    private String apellido; 
    private int edad; 

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

  
    public String getNombre() {      /* funcion get que toma  el nombre */
        return nombre;
    }
    
    public void setNombre(String nombre) { /* funcion set para asignar el nombre, tiene una variable nombre que es de entrada */
        this.nombre = nombre;/* asigna el nombre*/
    }

   
    
    
    
    
    
}
