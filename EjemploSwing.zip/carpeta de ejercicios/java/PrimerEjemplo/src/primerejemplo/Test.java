/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primerejemplo;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Test {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {    /* creo una instancia de alumno*/
       
    Scanner s = new Scanner(System.in);
    System.out.println("ingrese nombre");
    String nombre = s.nextLine();
    
    System.out.println("ingrese apellido");
    String apellido = s.nextLine();
    
    System.out.println("ingrese edad");
    int edad = s.nextInt();
       
       
       Alumno alu = new Alumno();
       //alu.setNombre("Sebastian");   /* mediante set le agrego un nombre*/
      // alu.setEdad(31);
       //alu.setApellido("Balmaceda");
       
       alu.setNombre(nombre);
       alu.setApellido(apellido);
       alu.setEdad(edad);
      
       
       
       //String nombre = alu.getNombre();/* creo una variable local nombre y le asigno el nombre que asigne a alumno*/
       System.out.println("Nombre: "+alu.getNombre());/* muestro por pantalla lo que le agregue a nombre*/
       System.out.println("Apellido: "+alu.getApellido());
       System.out.println("Edad: "+alu.getEdad());
   
   
  
   
   
   
   
   
   
   
   
   
   
   
   
   }
    
}



