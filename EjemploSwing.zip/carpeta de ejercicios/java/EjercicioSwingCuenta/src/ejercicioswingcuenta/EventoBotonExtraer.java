/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioswingcuenta;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Alumno
 */
public class EventoBotonExtraer  implements ActionListener { 
        
         private Cuenta cuenta = new Cuenta("pepe",0.0);
         private  JTextField importe;
         private JTextArea resultado;
     
        public EventoBotonExtraer(JTextField p, JTextArea resultado) { //construtor que va a tener un parametro de entrada
        importe = p;   //en este caso p sirve para poder obtener lo del teclado y asignaselo a importe
        this.resultado=resultado;
        }
     
     
            @Override
            public void actionPerformed(ActionEvent e) {
            //JButton boton = (JButton) e.getSource();
             //boton.setText("¡Gracias!");
        
             String imp = importe.getText();//a importe le asigno el immporte a string
                cuenta.extraer(Double.parseDouble(imp)); //parseo a double ingresar
                resultado.setText(cuenta.toString());

            }
    
    
}
