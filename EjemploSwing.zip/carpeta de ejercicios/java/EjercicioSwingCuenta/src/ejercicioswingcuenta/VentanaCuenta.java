/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioswingcuenta;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Alumno
 */
public class VentanaCuenta extends JFrame{
        
      public VentanaCuenta() {
            
        super("Añadir usuario");
        
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
     
 
        JPanel panel1 = new JPanel();
        GridLayout gl = new GridLayout(3,2,0,5);
        panel1.setLayout(gl);
        panel1.add(new JLabel("Titular:"));
        panel1.add(new JTextField(10));
        panel1.add(new JLabel("importe:"));
        JTextField imp = new JTextField(10);
        panel1.add(imp);
        
        
        
        JTextArea pepe = new JTextArea(3, 20);
       
        
        // Panel de botones
        JPanel panel2 = new JPanel();
        panel2.setLayout(new FlowLayout());
        
        JButton boton1 = new JButton("Extraer");
        boton1.addActionListener(new EventoBotonExtraer(imp,pepe));
        
        JButton boton2 = new JButton("Depositar");
        
        //HERNAN: Aca le paso el parametro del JTextArea
        boton2.addActionListener(new EventoBotonDepositar(imp, pepe));
        
        JButton boton3 = new JButton("Ver Saldo");
        boton3.addActionListener(new EventoBotonVerSaldo(pepe));
        
        panel2.setLayout(new FlowLayout());
        panel2.add(boton1);
        panel2.add(boton2);
        panel2.add(boton3);
        
        JPanel panel3= new JPanel();
        
        panel3.add(pepe);
      
        
        Container cp = getContentPane();
        cp.add(panel1, BorderLayout.NORTH);
        cp.add(panel2, BorderLayout.CENTER);
        cp.add(panel3, BorderLayout.SOUTH);
        
       }
       
   
   
   
}

