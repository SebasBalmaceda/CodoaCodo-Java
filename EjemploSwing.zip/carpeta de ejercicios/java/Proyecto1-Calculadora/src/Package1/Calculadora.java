/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Package1;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          int resultado=0;
          resultado= Operacion();
          System.out.println("el resultado de la operacion es  "+ resultado);}

    private static int Operacion() {
         int op=0;
         int result=0;
       Scanner s = new Scanner(System.in);
          Operador cal = new Operador(); 
          System.out.println("Elija que operacion quiere realizar");
          System.out.println("+................1");
          System.out.println("-................2");	
          System.out.println("*................3");	
          System.out.println("/................4");		
          cal.setOp(s.nextInt());
          op=cal.getOp();
           System.out.println("ingrese primer numero");			
            cal.setVal1(s.nextInt());
            System.out.println("ingrese segundo numero");
            cal.setVal2(s.nextInt());
          switch (op) {
 
            case 1:
            result=cal.sumar();
            break;
 
            case 2:
            result=cal.restar();
            break;
            
            case 3:
            result=cal.multiplicar();
             break;
        
            case 4:
            result=cal.dividir();
            break;
            
 
                       }
          return result; 
       }
    }
    
    
    




    
