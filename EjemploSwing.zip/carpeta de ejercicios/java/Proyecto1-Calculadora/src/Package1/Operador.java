/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Package1;

/**
 *
 * @author Sebas
 */
public class Operador {
     private int val1;
     private int val2;
     private int op;

    public int getOp() {
        return op;
    }

    public void setOp(int op) {
        this.op = op;
    }
    
     
    public int getVal1() {
        return val1;
    }

    public void setVal1(int val1) {
        this.val1 = val1;
    }

    public int getVal2() {
        return val2;
    }

    public void setVal2(int val2) {
        this.val2 = val2;
    }
   
     
    

   
   

public int sumar() {
        int resul=0;
        resul=val1+val2;
        return resul;}

public int restar() {
        int resul=0;
        resul=val1-val2;
        return resul;}

public int multiplicar() {
       int resul=0;
        resul=val1*val2;
        return resul;}

public int dividir() {
        int resul=0;
        resul=val1/val2;
        return resul;}
   
}