/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inter;

/**
 *
 * @author Alumno
 */
public class Auto implements AutoInterface{ //como usa interface esta obligado a usar los metodos de AutoInterface
    private int velocidad;

    @Override //SOBREESCRIBE
    public void acelerar(int cuantoAcelero) {
    }   
    
    @Override
    public void frenar(int cuantoVaFrenar) {
       
    }
}   
