/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inter;

/**
 *
 * @author Alumno
 */
public interface AutoInterface { //generico Y es publico,solo declaro codigo,comportamiento es como diseño
    public void acelerar(int cuantoAcelero);
    public void frenar(int cuantoVaFrenar);
}
