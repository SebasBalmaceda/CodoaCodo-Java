/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo2;

/**
 *
 * @author Sebas
 */
public class Calculador {
    private int num;
    private int cont;

    public int getNum() {
        return num;
    }

    public int getCont() {
        return cont;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }

 public int validaParImpar() {
        if( num % 2 == 0)  {
            cont++;
        }
        return cont;
    }




}