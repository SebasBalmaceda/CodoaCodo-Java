/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo2;
import java.util.Scanner;
/**
 *
 * @author Sebas
 */
public class Leer10Pares {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
            int resultado=0;
        resultado=CuentaPar();
        System.out.println("los pares leidos son "+ resultado);}
        
  
    
    public static int CuentaPar (){
                 Scanner s = new Scanner(System.in);
                 Calculador cal = new Calculador(); 
                 
        for(int i=1; i<=10; i ++){
            System.out.println("ingrese numero");			
            cal.setNum(s.nextInt());
            cal.validaParImpar();// no lleva parametros porque cal que es de tipo calculador, tiene datos e invoca a la funcion para que ejecute la operacion.
        }    
        
        return cal.getCont();
     
             
     }

    
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


