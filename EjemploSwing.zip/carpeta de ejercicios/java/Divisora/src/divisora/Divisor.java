/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package divisora;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Divisor {
   
      private int val1;
      private int val2;

    public Divisor(int val1, int val2) { //constructor
        setVal1(val1);
        setVal2(val2); 
    }

    public int getVal1() {
        return val1;
    }

    public void setVal1(int val1) {
        this.val1 = val1;
    }

    public void setVal2(int val2) {
        this.val2 = val2;
    }

    public int getVal2() {
        return val2;
    }
    
     public int dividir(){
        int resultado = 0;
        try {
            resultado = getVal1() / getVal2();
        } catch (Exception e) {
            System.out.println("Fallo la division"+e);
        }
        return resultado;
    }    
    
   
    
    
}
