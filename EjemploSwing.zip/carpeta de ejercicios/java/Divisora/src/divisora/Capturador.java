/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package divisora;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class Capturador {
    
    private Scanner s;

    public Capturador() {
        this.s = new Scanner(System.in);
    }
    
   
   
    
    public int Capturador(){ //funcion 
        int valor = 0;
        boolean bandera=true;
       do{  
           bandera=true;
        try {
            System.out.println("Ingrese numero ");
            valor = s.nextInt();
           } catch (Exception e) {
            System.out.println("no se puede leer letras  "+e);
            bandera=false;
            
            }
        
            }while(bandera=true);
            return valor;
         
        } 
    
    
    
}


