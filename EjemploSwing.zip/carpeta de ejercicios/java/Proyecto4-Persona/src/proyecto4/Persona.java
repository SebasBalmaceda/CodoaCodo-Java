/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto4;

/**
 *
 * @author Sebas
 */
public class Persona {
    private String nombre;
    private int edad;
    private String dni;
    private char sexo;
    private Double peso;
    private Double altura;

    public Persona() {
       
    
    }

    
    
    
    public Persona(String nombre, int edad, String dni, char sexo, Double peso, Double altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.dni =dni;
        this.sexo = sexo;
        this.peso = peso;
        this.altura =altura;
    }

    public Double getAltura() {
        return altura;
    }

    public String getDni() {
        return dni;
    }

    public int getEdad() {
        return edad;
    }

    public String getNombre() {
        return nombre;
    }

    public Double getPeso() {
        return peso;
    }

    public char getSexo() {
        return sexo;
    }

    public void setAltura(Double altura) {
        this.altura = altura;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }
   
    
    
}
   

    