/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tete;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Ejecutor {
     Scanner s = new Scanner (System.in);
   
     
     public void ejecutor(){ //metodo
        Scanner s = new Scanner (System.in);
   
        Divisor divisor= new Divisor();  
    
        System.out.println("ingrese un valor 1: ");
        int val1= s.nextInt();
    
        System.out.println("ingrese un valor 2: ");
        int val2= s.nextInt();    
    
        divisor.setVal1(val1);
        divisor.setVal2(val2);
        int resultado = divisor.dividir();
        System.out.println(resultado);   
        
        }
}
