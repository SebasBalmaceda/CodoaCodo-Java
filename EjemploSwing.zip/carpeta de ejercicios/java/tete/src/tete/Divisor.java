/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tete;

/**
 *
 * @author Alumno
 */
public class Divisor extends Scaneador {
    public int dividir (){
     return this.getVal1()/ this.getVal2();
        
        
    }
}
