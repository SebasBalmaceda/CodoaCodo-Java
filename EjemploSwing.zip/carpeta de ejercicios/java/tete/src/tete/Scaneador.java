/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tete;

/**
 *
 * @author Alumno
 */
public class Scaneador {
    private int Val1;
    private int Val2;

  
    
    

    public int getVal1() {
        return Val1;
    }

    public void setVal1(int Val1) {
        this.Val1 = Val1;
    }

    public void setVal2(int Val2) {
        this.Val2 = Val2;
    }

    public int getVal2() {
        return Val2;
    }
    
    
}
