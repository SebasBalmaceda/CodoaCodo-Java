/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3.cuenta;

/**
 *
 * @author Alumno
 */
public class Cuenta {
    private String titular;
    private double cantidad;
    

   

    
    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public String getTitular() {
        return titular;
    }

    @Override
    public String toString() { //
        return ("el saldo de la cuenta es: "+cantidad); 
    }

    
    
    public void ingresar(double cantidad){
        double saldo=0;
        double ingreso=0;
        ingreso=getCantidad();
            if (ingreso<0){
                setCantidad(saldo);
            }
            
         }
       
    
    
    public void retirar(double cantidad){
        double saldo=0;
        double retiro=0;
        retiro=getCantidad();
        saldo=saldo-retiro;
            if (saldo<0){
            setCantidad(0);  
            }
    
    }
        
    
}  

