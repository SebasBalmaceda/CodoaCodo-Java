/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3.cuenta;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Ejecutor {
     Scanner s = new Scanner (System.in);
        
        public void ejecutor(){ //metodo
       
        Boolean si=true;
        Boolean no=false;
        
        Cuenta cuenta= new Cuenta();  
            try{
                System.out.println("Bienvenido a Balinko ");
                System.out.println("ingrese nombre de titular de la cuenta: ");
                String titular= s.next();
                cuenta.setTitular(titular);
                }catch(Exception e){
                System.out.println("no se pudo leer el nombre del titular vuelva a ingresar"+e);}
                                                                                                        
                    System.out.println("el nombre del titular es "+cuenta.getTitular());
                do {                   
                     //Menu de gestion para el usuario
                       System.out.println("Menu");
                       System.out.println("¿que operacion desea realizar?");
                       System.out.println("Ingresar..................1");
                       System.out.println("Retirar...................2");
                       
                       int op=s.nextInt();
                        if (op==1){
                            System.out.println("ingrese la cantidad de la cuenta: ");
                            double cantidad= s.nextDouble();
                            cuenta.setCantidad(cantidad);
                            cuenta.ingresar(cantidad);
                            System.out.println(cuenta);
                        }else{
                            System.out.println("ingrese la cantidad a retirar de la cuenta: ");
                            double cantidad= s.nextDouble();
                            cuenta.setCantidad(cantidad);
                            cuenta.retirar(cantidad);
                            System.out.println(cuenta);}
                  
                
                
               
                        System.out.println("Desea Salir s/n: ");
                        Boolean  bandera = s.nextBoolean();
                    }while (bandera==b);
            
        }         


}