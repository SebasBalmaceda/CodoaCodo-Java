/* Este codigo ha sido generado por el modulo psexport 20160506-w32 de PSeInt.
Es posible que el codigo generado no sea completamente correcto. Si encuentra
errores por favor reportelos en el foro (http://pseint.sourceforge.net). */

// En java, el nombre de un archivo fuente debe coincidir con el nombre de la clase que contiene,
// por lo que este archivo deber�a llamarse "PAR_IMPAR.java."

import java.io.*;

public class par_impar {

	public static void main(String args[]) throws IOException {
		BufferedReader bufEntrada = new BufferedReader(new InputStreamReader(System.in));
		double a;
		System.out.println("Ingrese un numero");
		a = bufEntrada.readLine();
		if ((a%2==0)) {
			System.out.println("Numero es par");
		} else {
			System.out.println("Numero es impar");
		}
	}


}

