/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pepe;

/**
 *
 * @author Alumno
 */
public class Operador { // esta clase solo hace los get y set
    private int val1;
    private int val2;
    private String opera;
    
   

    public String getOpera() {
        return opera;
    }

    public void setOpera(String opera) {
        this.opera = opera;
    }

    public int getVal1() {
        return val1;
    }

    public void setVal1(int val1) {
        this.val1 = val1;
    }

    public void setVal2(int val2) {
        this.val2 = val2;
    }

    public int getVal2() {
        return val2;
    }
    
    
    
}
