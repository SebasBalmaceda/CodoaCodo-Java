/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pepe;

/**
 *
 * @author Alumno
 */
public class Sumador extends Operador{ //clase que hereda de operador y posee la funcion de sumar
     
   
    public int sumar(){
      return this.getVal1()+ this.getVal2();
    }
    
    
}
