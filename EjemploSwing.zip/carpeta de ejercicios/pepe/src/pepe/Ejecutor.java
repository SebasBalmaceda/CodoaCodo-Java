/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pepe;

import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class Ejecutor {     // clase principal
     Scanner s = new Scanner (System.in);
   
    
    /*public Ejecutor(){    //constructor 
    Scanner s = new Scanner (System.in);
   
    Sumador sumador= new Sumador();  
    
    System.out.println("ingrese un valor 1: ");
    int val1= s.nextInt();
    
    System.out.println("ingrese un valor 2: ");
    int val2= s.nextInt();    
    
    sumador.setVal1(val1);
    sumador.setVal2(val2);
    int resultado = sumador.sumar();
    System.out.println(resultado);
    }*/
    
        public void ejecutor(){ //metodo
        Scanner s = new Scanner (System.in);
   
        Sumador sumador= new Sumador();  
    
        System.out.println("ingrese un valor 1: ");
        int val1= s.nextInt();
    
        System.out.println("ingrese un valor 2: ");
        int val2= s.nextInt();    
    
        sumador.setVal1(val1);
        sumador.setVal2(val2);
        int resultado = sumador.sumar();
        System.out.println(resultado);   
        
        }
    
    
}
