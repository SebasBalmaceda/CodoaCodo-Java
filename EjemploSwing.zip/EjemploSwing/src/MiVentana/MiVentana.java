/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MiVentana;

import javax.swing.JFrame;

/**
 *
 * @author Alumno
 */
public class MiVentana extends JFrame {
  
    public MiVentana() {
    super("Titulo de ventana");//llama al constructor del padre
    setSize(400, 300);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}


