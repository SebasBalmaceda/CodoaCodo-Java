/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploswing;

import javax.swing.JFrame;

/**
 *
 * @author Alumno
 */
public class EjemploSwing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
    JFrame f = new JFrame("Titulo de ventana");
    f.setSize(400, 300);
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    f.setVisible(true);
 }
        
        
    }
    

